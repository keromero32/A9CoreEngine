# A9 Core — GitHub Actions APK Build

This package is prepared for cloud APK builds with GitHub Actions. It contains the Android Gradle project, Vulkan/NDK native code, CMake configuration, and a workflow that produces a debug APK.

## GitHub
1. Create a new GitHub repository.
2. Upload/extract all files from this ZIP into the repository root.
3. Push to the `main` branch.
4. Open **Actions → Build A9 Core APK**.
5. For a manual build, choose **Run workflow**.
6. When the job finishes, download the **A9Core-debug-apk** artifact.

The workflow uses JDK 17, Android API 35, NDK 27.0.12077973, CMake 3.22.1, and Gradle 8.9.
