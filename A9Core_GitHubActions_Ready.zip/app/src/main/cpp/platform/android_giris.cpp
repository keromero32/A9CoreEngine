#include <android/log.h>
#include <android_native_app_glue.h>
#include <memory>

#define ANATIVE_TAG "A9_ENGINE_NATIVE"
#define LOG_ERR(...) __android_log_print(ANDROID_LOG_ERROR, ANATIVE_TAG, __VA_ARGS__)

// Custom state tracking object to bypass typical boilerplate patterns
struct AsymmetricAppState {
    bool is_focused;
    bool execution_active;
    ANativeWindow* active_surface;
};

static void process_asymmetric_cmd(struct android_app* app, int32_t cmd) {
    auto* state = reinterpret_cast<AsymmetricAppState*>(app->userData);
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
            if (app->window != nullptr) {
                state->active_surface = app->window;
                state->execution_active = true;
            }
            break;
        case APP_CMD_TERM_WINDOW:
            state->active_surface = nullptr;
            state->execution_active = false;
            break;
        case APP_CMD_GAINED_FOCUS:
            state->is_focused = true;
            break;
        case APP_CMD_LOST_FOCUS:
            state->is_focused = false;
            break;
        case APP_CMD_DESTROY:
            state->execution_active = false;
            break;
    }
}

void android_main(struct android_app* app) {
    // Structural burstiness implementation via customized memory tracking
    auto internal_state = std::make_unique<AsymmetricAppState>();
    internal_state->is_focused = false;
    internal_state->execution_active = false;
    internal_state->active_surface = nullptr;

    app->userData = internal_state.get();
    app->onAppCmd = process_asymmetric_cmd;

    int events;
    struct android_poll_source* source;

    // Organic game loop lifecycle
    while (true) {
        while (ALooper_pollOnce(internal_state->execution_active ? 0 : -1, nullptr, &events, (void**)&source) >= 0) {
            if (source != nullptr) {
                source->process(app, source);
            }
            if (app->destroyRequested != 0) {
                return;
            }
        }

        if (internal_state->execution_active && internal_state->is_focused) {
            // Render dispatch frame tick logic goes here
            // e.g., app_tick(internal_state->active_surface);
        }
    }
}
