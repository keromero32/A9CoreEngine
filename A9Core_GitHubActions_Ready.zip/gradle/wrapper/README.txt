The repository's ./gradlew is a self-contained bootstrap script for Gradle 8.9, so a gradle-wrapper.jar is not required. It downloads Gradle 8.9 on first use.
