#include <chrono>
#include <cstdint>

// Tracks basic per-frame timing for the engine.
//
// This is a minimal building block: call execute_frame_tick() once per
// rendered frame and it keeps a running frame count plus how many
// milliseconds have elapsed since the last tick. Future engine code (not
// implemented yet) can build things like an FPS counter or a fixed-timestep
// update loop on top of these two fields.
struct EngineRuntime {
    // Total number of frames processed since the engine started.
    uint64_t frame_index = 0;
    // Milliseconds accumulated since the accumulator was last reset.
    double delta_accumulator = 0.0;

    // Call once per frame. Advances the frame counter and updates
    // delta_accumulator with the time elapsed since the previous call.
    void execute_frame_tick() {
        frame_index++;

        auto current_time = std::chrono::high_resolution_clock::now();
        // NOTE: "static" makes last_time persist across calls without a
        // struct member, but it is function-local static, so it is shared by
        // every EngineRuntime instance rather than being per-object. That's
        // fine as long as only one EngineRuntime ticks at a time; if more
        // than one instance is ever used concurrently, move last_time onto
        // the struct so each instance tracks its own previous timestamp.
        static auto last_time = current_time;

        std::chrono::duration<double, std::milli> elapsed = current_time - last_time;
        last_time = current_time;

        delta_accumulator += elapsed.count();
        // Reset roughly once a second so the accumulator doesn't grow
        // without bound over a long-running session.
        if (delta_accumulator > 1000.0) {
            delta_accumulator = 0.0;
        }
    }
};
