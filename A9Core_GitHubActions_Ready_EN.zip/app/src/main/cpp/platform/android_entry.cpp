#include <android/log.h>
#include <android_native_app_glue.h>
#include <memory>

// Log tag used for this native library's error-level logs (visible via
// `adb logcat` or Android Studio's Logcat, filtered on this tag).
#define ANATIVE_TAG "A9_ENGINE_NATIVE"
#define LOG_ERR(...) __android_log_print(ANDROID_LOG_ERROR, ANATIVE_TAG, __VA_ARGS__)

// Lifecycle/window state for the native activity. A pointer to one of these
// is stashed in android_app::userData (see android_main below) so the
// command callback can read and update it as OS events arrive.
struct AsymmetricAppState {
    bool is_focused;               // Whether the app currently has input focus.
    bool execution_active;         // Whether there's a live window to render into.
    ANativeWindow* active_surface; // The current native window, or null.
};

// Callback registered as android_app::onAppCmd. android_native_app_glue
// calls this whenever the OS sends a lifecycle event (window created/
// destroyed, focus gained/lost, activity destroyed, etc.), and this function
// updates AsymmetricAppState accordingly so the main loop below knows
// whether it's safe and useful to render.
static void process_asymmetric_cmd(struct android_app* app, int32_t cmd) {
    auto* state = reinterpret_cast<AsymmetricAppState*>(app->userData);
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
            // A native window is now available; safe to start rendering.
            if (app->window != nullptr) {
                state->active_surface = app->window;
                state->execution_active = true;
            }
            break;
        case APP_CMD_TERM_WINDOW:
            // The window is being destroyed (e.g. app backgrounded); stop
            // rendering until APP_CMD_INIT_WINDOW fires again.
            state->active_surface = nullptr;
            state->execution_active = false;
            break;
        case APP_CMD_GAINED_FOCUS:
            state->is_focused = true;
            break;
        case APP_CMD_LOST_FOCUS:
            state->is_focused = false;
            break;
        case APP_CMD_DESTROY:
            state->execution_active = false;
            break;
    }
}

// Native entry point. android_native_app_glue exports the symbol NDK's
// NativeActivity looks for and calls this function once it's ready, making
// it the native equivalent of `main` for this app.
void android_main(struct android_app* app) {
    // Heap-allocate the state and store a raw pointer in app->userData: the
    // android_app struct is owned/managed by native_app_glue for the whole
    // life of the app, so this state needs to outlive this function's own
    // scope. unique_ptr keeps android_main responsible for the allocation's
    // lifetime even though it's the raw pointer that actually gets shared
    // with the callback above.
    auto internal_state = std::make_unique<AsymmetricAppState>();
    internal_state->is_focused = false;
    internal_state->execution_active = false;
    internal_state->active_surface = nullptr;

    app->userData = internal_state.get();
    app->onAppCmd = process_asymmetric_cmd;

    int events;
    struct android_poll_source* source;

    // Standard native_app_glue main loop.
    while (true) {
        // Block indefinitely (-1) for the next event while there's nothing
        // to render (e.g. the app is paused/backgrounded); poll without
        // blocking (0) once there's an active window, so rendering can
        // proceed in between handling events.
        while (ALooper_pollOnce(internal_state->execution_active ? 0 : -1, nullptr, &events, (void**)&source) >= 0) {
            if (source != nullptr) {
                source->process(app, source);
            }
            if (app->destroyRequested != 0) {
                return;
            }
        }

        if (internal_state->execution_active && internal_state->is_focused) {
            // TODO: engine render/update dispatch goes here once the
            // renderer exists, e.g. app_tick(internal_state->active_surface);
        }
    }
}
