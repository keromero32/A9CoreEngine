// VK_USE_PLATFORM_ANDROID_KHR must be defined before including vulkan.h so
// the header exposes the Android-specific surface types/functions used
// below (VkAndroidSurfaceCreateInfoKHR, etc.). CMakeLists.txt also defines
// this globally for the whole target, so this line is mostly defensive/
// documentation in case this file is ever compiled on its own.
#define VK_USE_PLATFORM_ANDROID_KHR
#include <vulkan/vulkan.h>
#include <android/native_window.h>
#include <vector>

// Owns the Vulkan objects needed to get a renderable surface on screen: the
// Vulkan instance and the Android window surface. physical_device is
// reserved for GPU selection, which (along with the logical device and
// actual rendering) isn't implemented yet.
class GpuContext {
public:
    VkInstance instance{VK_NULL_HANDLE};
    VkSurfaceKHR surface{VK_NULL_HANDLE};
    VkPhysicalDevice physical_device{VK_NULL_HANDLE};

    // Creates the Vulkan instance and wraps the given native window in a
    // VkSurfaceKHR. Returns false if any Vulkan call fails; instance and/or
    // surface may be left partially initialized in that case, so callers
    // should still call shutdown() to clean up whatever was created.
    bool init_vulkan_runtime(ANativeWindow* window) {
        VkApplicationInfo app_info{};
        app_info.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
        app_info.pApplicationName = "A9VulkanEngine";
        app_info.applicationVersion = VK_MAKE_VERSION(1, 0, 0);
        app_info.pEngineName = "CustomAsymmetric";
        app_info.engineVersion = VK_MAKE_VERSION(1, 0, 0);
        // Vulkan 1.1 is requested explicitly, rather than leaving this at
        // whatever the default would be, since it's the minimum needed for
        // reliable behavior on Adreno 619 (and similar) mobile GPU driver
        // profiles.
        app_info.apiVersion = VK_API_VERSION_1_1;

        // VK_KHR_surface: generic (platform-agnostic) surface support.
        // VK_KHR_android_surface: Android-specific extension that adds
        // vkCreateAndroidSurfaceKHR, used below to wrap the ANativeWindow.
        std::vector<const char*> extensions = {
            "VK_KHR_surface",
            "VK_KHR_android_surface"
        };

        VkInstanceCreateInfo create_info{};
        create_info.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
        create_info.pApplicationInfo = &app_info;
        create_info.enabledExtensionCount = static_cast<uint32_t>(extensions.size());
        create_info.ppEnabledExtensionNames = extensions.data();

        if (vkCreateInstance(&create_info, nullptr, &instance) != VK_SUCCESS) {
            return false;
        }

        // Describes the ANativeWindow we want Vulkan to render into.
        VkAndroidSurfaceCreateInfoKHR surface_info{};
        surface_info.sType = VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR;
        surface_info.window = window;

        // vkCreateAndroidSurfaceKHR comes from the VK_KHR_android_surface
        // extension enabled above rather than from core Vulkan, so it has no
        // statically linked entry point in the loader; it has to be resolved
        // at runtime via vkGetInstanceProcAddr before it can be called.
        auto fpCreateAndroidSurfaceKHR = (PFN_vkCreateAndroidSurfaceKHR)vkGetInstanceProcAddr(instance, "vkCreateAndroidSurfaceKHR");
        if (!fpCreateAndroidSurfaceKHR || fpCreateAndroidSurfaceKHR(instance, &surface_info, nullptr, &surface) != VK_SUCCESS) {
            return false;
        }

        return true;
    }

    // Releases the Vulkan objects owned by this context. The surface is
    // destroyed before the instance because it was created from (and
    // depends on) that instance — destroying them in the opposite order is
    // invalid per the Vulkan spec.
    void shutdown() {
        if (surface != VK_NULL_HANDLE) {
            vkDestroySurfaceKHR(instance, surface, nullptr);
        }
        if (instance != VK_NULL_HANDLE) {
            vkDestroyInstance(instance, nullptr);
        }
    }
};
