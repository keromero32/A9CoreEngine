package com.a9core.engine;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

/**
 * Plain Java Activity that removes the title bar and forces fullscreen.
 *
 * Note: AndroidManifest.xml currently launches android.app.NativeActivity
 * instead of this class, so MainActivity is not part of the active launch
 * path — the native engine (app/src/main/cpp) manages the window directly.
 * This class is kept as a ready-made fallback / UI entry point in case a
 * Java-driven (non-NativeActivity) launch is needed later.
 */
public final class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        // Remove the title bar...
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        // ...and hide the system UI so the app can use the entire screen.
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
    }
}
