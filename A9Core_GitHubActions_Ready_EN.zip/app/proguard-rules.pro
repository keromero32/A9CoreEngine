# ProGuard/R8 keep rules for the "release" build type.
#
# No custom rules are needed yet because minifyEnabled and shrinkResources
# are both set to false for "release" in app/build.gradle, so R8 doesn't
# actually shrink/obfuscate anything right now. This file is still wired
# into the build (see proguardFiles in app/build.gradle) so project-specific
# keep rules can be added here later without touching the build script, if
# shrinking is turned on.
